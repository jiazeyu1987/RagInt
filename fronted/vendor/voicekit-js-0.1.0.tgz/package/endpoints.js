export function buildAsrWsUrl(baseUrl, { path = '/voicekit/ws/asr' } = {}) {
  const b = String(baseUrl || '').replace(/\/+$/, '');
  if (!b) throw new Error('Missing baseUrl');
  const u = new URL(b);
  const wsProto = u.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${wsProto}//${u.host}${path}`;
}

