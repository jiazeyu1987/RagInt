import { buildAsrWsUrl } from './endpoints.js';
import { makeStart } from './protocol.js';
export { createMicRecorder } from './mic_recorder.js';

function safeTrim(v) {
  return String(v == null ? '' : v).trim();
}

export function createVoiceInputManager({
  baseUrl,
  clientId,
  authToken,
  onStatus,
  onWake,
  onPartial,
  onFinal,
  onError,
} = {}) {
  let ws = null;
  let stopping = false;
  let awakened = false;
  let stopCloseTimer = null;
  let wakeDeadlineMs = 0;

  function emitStatus(message) {
    const m = safeTrim(message);
    if (m && typeof onStatus === 'function') onStatus(m);
  }

  function closeWs() {
    const w = ws;
    ws = null;
    if (stopCloseTimer) {
      try {
        clearTimeout(stopCloseTimer);
      } catch (_) {
        // ignore
      }
      stopCloseTimer = null;
    }
    if (!w) return;
    try {
      w.onopen = null;
      w.onmessage = null;
      w.onerror = null;
      w.onclose = null;
      w.close();
    } catch (_) {
      // ignore
    }
  }

  async function startHoldToTalk({
    wakeEnabled = false,
    wakeWords = null,
    wakeWord = '',
    authToken: authTokenOverride,
    strict = false,
    cooldownMs = 0,
    wakeMaxPos = strict ? 0 : 2,
  } = {}) {
    if (ws) closeWs();
    stopping = false;
    awakened = !wakeEnabled;
    wakeDeadlineMs = 0;

    const url = buildAsrWsUrl(baseUrl);
    ws = new WebSocket(url);
    ws.binaryType = 'arraybuffer';

    ws.onmessage = (ev) => {
      let msg = null;
      try {
        msg = typeof ev.data === 'string' ? JSON.parse(ev.data) : null;
      } catch (_) {
        msg = null;
      }
      if (!msg) return;
      const t = safeTrim(msg.type).toLowerCase();
      if (t === 'info') emitStatus(msg.message);
      if (t === 'wake') {
        awakened = true;
        wakeDeadlineMs = Math.max(0, Number(msg.wake_deadline_ms) || 0);
        const reason = safeTrim(msg.wake_reason);
        const remainMs = wakeDeadlineMs ? Math.max(0, wakeDeadlineMs - Date.now()) : 0;
        const remainS = remainMs ? Math.ceil(remainMs / 1000) : 0;
        const prefix = reason === 'hold_window' ? '窗口内已唤醒' : '已唤醒';
        emitStatus(remainS ? `${prefix}（保持${remainS}s）` : prefix);
        if (typeof onWake === 'function') onWake(msg);
        return;
      }
      if (t === 'partial') {
        if (!awakened) return;
        const text = safeTrim(msg.text);
        if (text && typeof onPartial === 'function') onPartial(text, msg);
        return;
      }
      if (t === 'final') {
        if (!awakened) return;
        const text = safeTrim(msg.text);
        if (text && typeof onFinal === 'function') onFinal(text, msg);
        if (stopping) closeWs();
        return;
      }
      if (t === 'error') {
        const e = safeTrim(msg.error || msg.message || 'unknown');
        if (!stopping && typeof onError === 'function') onError(e, msg);
        if (stopping) closeWs();
      }
    };

    ws.onerror = () => {
      if (stopping) return;
      if (typeof onError === 'function') onError('ws_error');
      closeWs();
    };

    await new Promise((resolve) => {
      ws.onopen = () => resolve();
      ws.onclose = () => resolve();
    });

    if (!ws || ws.readyState !== WebSocket.OPEN) {
      if (typeof onError === 'function') onError('ws_not_open');
      return;
    }

    const startMsg = makeStart({
      requestId: `vk_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      clientId: String(clientId || ''),
      authToken: String(authTokenOverride != null ? authTokenOverride : authToken || ''),
      wakeEnabled: !!wakeEnabled,
      wakeWords: Array.isArray(wakeWords) ? wakeWords : null,
      wakeWord: String(wakeWord || ''),
      wakeMatchMode: strict ? 'prefix' : 'contains',
      wakeCooldownMs: Number(cooldownMs) || 0,
      wakeMaxPos,
      continuous: false,
      emitPrewake: false,
    });

    ws.send(JSON.stringify(startMsg));
  }

  function sendAudioFrame(pcm16leArrayBuffer) {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    try {
      ws.send(pcm16leArrayBuffer);
    } catch (_) {
      // ignore
    }
  }

  function stopHoldToTalk() {
    if (!ws) return;
    stopping = true;
    try {
      ws.send(JSON.stringify({ type: 'stop' }));
    } catch (_) {
      // ignore
    }
    if (stopCloseTimer) clearTimeout(stopCloseTimer);
    // Safety net: if server/provider never returns final, still close to release resources.
    stopCloseTimer = setTimeout(() => closeWs(), 2500);
  }

  function cancel() {
    if (!ws) return;
    stopping = true;
    try {
      ws.send(JSON.stringify({ type: 'cancel' }));
    } catch (_) {
      // ignore
    }
    closeWs();
  }

  function dispose() {
    closeWs();
  }

  return { startHoldToTalk, sendAudioFrame, stopHoldToTalk, cancel, dispose };
}

