function safeTrim(v) {
  return String(v == null ? '' : v).trim();
}

function downsampleTo16kMono(float32, srcRate, dstRate = 16000) {
  const rate = Number(srcRate) || 48000;
  const target = Number(dstRate) || 16000;
  if (rate === target) return float32;
  const ratio = rate / target;
  const newLen = Math.max(1, Math.round(float32.length / ratio));
  const out = new Float32Array(newLen);
  for (let i = 0; i < newLen; i++) {
    const pos = i * ratio;
    const left = Math.floor(pos);
    const right = Math.min(float32.length - 1, left + 1);
    const w = pos - left;
    out[i] = float32[left] * (1 - w) + float32[right] * w;
  }
  return out;
}

function floatToInt16Bytes(float32) {
  const buf = new ArrayBuffer(float32.length * 2);
  const view = new DataView(buf);
  for (let i = 0; i < float32.length; i++) {
    let s = float32[i];
    if (s > 1) s = 1;
    if (s < -1) s = -1;
    view.setInt16(i * 2, Math.round(s * 32767), true);
  }
  return buf;
}

async function createAudioContextPreferRate(sampleRate) {
  try {
    return new (window.AudioContext || window.webkitAudioContext)({ sampleRate });
  } catch (_) {
    return new (window.AudioContext || window.webkitAudioContext)();
  }
}

export function createMicRecorder({
  dstSampleRate = 16000,
  chunkMs = 20,
  deviceId = '',
  echoCancellation = true,
  noiseSuppression = true,
  autoGainControl = true,
  onFrame,
  onStats,
  onError,
} = {}) {
  let stream = null;
  let audioContext = null;
  let sourceNode = null;
  let workletNode = null;
  let processorNode = null;
  let started = false;
  let mode = 'none'; // worklet | fallback

  async function start() {
    if (started) return { mode };
    started = true;
    mode = 'none';

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: !!echoCancellation,
          noiseSuppression: !!noiseSuppression,
          autoGainControl: !!autoGainControl,
          ...(safeTrim(deviceId) ? { deviceId: { exact: safeTrim(deviceId) } } : {}),
        },
      });
    } catch (e) {
      started = false;
      if (typeof onError === 'function') onError(e);
      throw e;
    }

    audioContext = await createAudioContextPreferRate(Number(dstSampleRate) || 16000);
    try {
      if (audioContext && audioContext.state === 'suspended' && typeof audioContext.resume === 'function') {
        await audioContext.resume();
      }
    } catch (_) {}

    sourceNode = audioContext.createMediaStreamSource(stream);

    const canWorklet =
      audioContext.audioWorklet &&
      typeof audioContext.audioWorklet.addModule === 'function' &&
      typeof window.AudioWorkletNode === 'function';

    if (canWorklet) {
      try {
        const url = new URL('./worklet/pcm16_encoder_worklet.js', import.meta.url);
        await audioContext.audioWorklet.addModule(url);
        workletNode = new AudioWorkletNode(audioContext, 'pcm16-encoder', {
          numberOfInputs: 1,
          numberOfOutputs: 1,
          outputChannelCount: [1],
          processorOptions: { dstSampleRate: Number(dstSampleRate) || 16000, chunkMs: Number(chunkMs) || 20 },
        });
        workletNode.port.onmessage = (ev) => {
          if (!started) return;
          const msg = ev.data;
          if (msg && msg.kind === 'pcm' && msg.buf instanceof ArrayBuffer) {
            if (typeof onFrame === 'function') onFrame(msg.buf);
            return;
          }
          if (msg && msg.kind === 'stats') {
            if (typeof onStats === 'function') onStats(msg);
          }
        };
        sourceNode.connect(workletNode);
        workletNode.connect(audioContext.destination);
        mode = 'worklet';
        return { mode };
      } catch (e) {
        workletNode = null;
      }
    }

    processorNode = audioContext.createScriptProcessor(2048, 1, 1);
    processorNode.onaudioprocess = (e) => {
      if (!started) return;
      const input = e.inputBuffer.getChannelData(0);
      const down = downsampleTo16kMono(input, audioContext.sampleRate, Number(dstSampleRate) || 16000);
      const buf = floatToInt16Bytes(down);
      if (typeof onFrame === 'function') onFrame(buf);
      if (typeof onStats === 'function') {
        let sum = 0;
        let peak = 0;
        for (let i = 0; i < down.length; i++) sum += down[i] * down[i];
        for (let i = 0; i < down.length; i++) {
          const a = Math.abs(down[i]);
          if (a > peak) peak = a;
        }
        const rms = Math.sqrt(sum / Math.max(1, down.length));
        onStats({ kind: 'stats', rms, peak });
      }
    };
    sourceNode.connect(processorNode);
    processorNode.connect(audioContext.destination);
    mode = 'fallback';
    return { mode };
  }

  function stop() {
    started = false;
    try {
      if (processorNode) processorNode.disconnect();
    } catch (_) {}
    try {
      if (workletNode) workletNode.disconnect();
    } catch (_) {}
    try {
      if (sourceNode) sourceNode.disconnect();
    } catch (_) {}
    processorNode = null;
    workletNode = null;
    sourceNode = null;
    try {
      if (audioContext) audioContext.close();
    } catch (_) {}
    audioContext = null;
    try {
      if (stream) stream.getTracks().forEach((t) => t.stop());
    } catch (_) {}
    stream = null;
  }

  function getState() {
    return {
      started,
      mode,
      sampleRate: audioContext ? Number(audioContext.sampleRate) || 0 : 0,
    };
  }

  return { start, stop, getState };
}
