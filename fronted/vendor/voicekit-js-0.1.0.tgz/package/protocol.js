export function makeStart({
  requestId,
  clientId,
  authToken = '',
  sampleRate = 16000,
  encoding = 'pcm_s16le',
  continuous = false,
  wakeEnabled = false,
  wakeWords = null,
  wakeWord = '',
  wakeMatchMode = 'contains',
  wakeCooldownMs = 0,
  wakeMaxPos = 2,
  emitPrewake = false,
} = {}) {
  const parsedWakeWords = Array.isArray(wakeWords)
    ? wakeWords
        .map((w) => String(w == null ? '' : w).trim())
        .filter((w) => !!w)
    : String(wakeWord || '')
        .split(/[,\uFF0C]/g)
        .map((w) => String(w == null ? '' : w).trim())
        .filter((w) => !!w);

  const primaryWakeWord = parsedWakeWords[0] ? String(parsedWakeWords[0]) : String(wakeWord || '');

  return {
    type: 'start',
    protocol_version: 1,
    request_id: String(requestId || ''),
    client_id: String(clientId || ''),
    auth_token: String(authToken || ''),
    sample_rate: Number(sampleRate) || 16000,
    encoding: String(encoding || 'pcm_s16le'),
    continuous: !!continuous,
    wake_word_enabled: !!wakeEnabled,
    wake_word: primaryWakeWord,
    wake_words: parsedWakeWords,
    wake_match_mode: String(wakeMatchMode || 'contains'),
    wake_cooldown_ms: Math.max(0, Number(wakeCooldownMs) || 0),
    wake_max_pos: Math.max(0, Math.min(20, Number(wakeMaxPos) || 0)),
    emit_prewake: !!emitPrewake,
  };
}
