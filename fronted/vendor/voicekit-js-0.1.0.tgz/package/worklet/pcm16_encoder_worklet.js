class Pcm16EncoderProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const opt = (options && options.processorOptions) || {};
    this.dstRate = Math.max(8000, Number(opt.dstSampleRate) || 16000);
    this.chunkMs = Math.max(5, Number(opt.chunkMs) || 20);
    this.chunkSamples = Math.max(80, Math.round((this.dstRate * this.chunkMs) / 1000));

    this._srcOffset = 0;
    this._prevSample = 0;
    this._havePrev = false;
    this._ratio = sampleRate / this.dstRate;
    this._chunk = new Float32Array(this.chunkSamples);
    this._chunkPos = 0;
    this._statN = 0;
    this._statSumSq = 0;
    this._statFrames = 0;
    this._statPeak = 0;
  }

  _floatToPcm16LEBytes(floatArray) {
    const buf = new ArrayBuffer(floatArray.length * 2);
    const view = new DataView(buf);
    for (let i = 0; i < floatArray.length; i++) {
      let s = floatArray[i];
      if (s > 1) s = 1;
      if (s < -1) s = -1;
      view.setInt16(i * 2, Math.round(s * 32767), true);
    }
    return buf;
  }

  _emitPcmChunk() {
    const bytes = this._floatToPcm16LEBytes(this._chunk);
    this.port.postMessage({ kind: 'pcm', buf: bytes }, [bytes]);
  }

  _pushSampleToChunk(s) {
    this._chunk[this._chunkPos++] = s;
    if (this._chunkPos >= this.chunkSamples) {
      this._chunkPos = 0;
      this._emitPcmChunk();
    }
  }

  _resampleAndPush(input) {
    if (sampleRate === this.dstRate) {
      for (let i = 0; i < input.length; i++) this._pushSampleToChunk(input[i]);
      this._prevSample = input[input.length - 1] || 0;
      this._havePrev = true;
      return;
    }

    let pos = this._srcOffset; // position in the current input buffer
    const max = input.length - 1;

    // If we have a carried fractional offset, the first interpolated sample may lie
    // between the previous block's last sample and this block's first sample.
    if (!this._havePrev) {
      this._prevSample = input[0] || 0;
      this._havePrev = true;
    }
    while (pos < 1 && pos < max) {
      const w = pos; // 0..1
      const s = this._prevSample * (1 - w) + input[0] * w;
      this._pushSampleToChunk(s);
      pos += this._ratio;
    }

    while (pos < max) {
      const left = pos | 0;
      const right = left + 1;
      const w = pos - left;
      const s = input[left] * (1 - w) + input[right] * w;
      this._pushSampleToChunk(s);
      pos += this._ratio;
    }

    // Carry over offset into next block; keep last sample for continuity.
    this._srcOffset = pos - max;
    this._prevSample = input[max] || 0;
  }

  process(inputs, outputs) {
    const input = inputs && inputs[0] && inputs[0][0];
    // Ensure we output silence (avoid any audible feedback when connected to destination).
    if (outputs && outputs[0] && outputs[0][0]) outputs[0][0].fill(0);
    if (!input) return true;

    // RMS/peak stats on source rate samples (cheap).
    for (let i = 0; i < input.length; i++) {
      const s = input[i];
      this._statSumSq += s * s;
      this._statN += 1;
      const a = s < 0 ? -s : s;
      if (a > this._statPeak) this._statPeak = a;
    }
    this._statFrames += 1;
    // roughly every ~250ms at 48k/128 (~187fps), but keep it simple:
    if (this._statFrames >= 15 && this._statN > 0) {
      const rms = Math.sqrt(this._statSumSq / this._statN);
      this.port.postMessage({ kind: 'stats', rms, peak: this._statPeak });
      this._statN = 0;
      this._statSumSq = 0;
      this._statFrames = 0;
      this._statPeak = 0;
    }

    this._resampleAndPush(input);
    return true;
  }
}

registerProcessor('pcm16-encoder', Pcm16EncoderProcessor);
